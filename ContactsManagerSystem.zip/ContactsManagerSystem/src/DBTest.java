import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBTest {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/contacts_db"; // your DB name
        String user = "root"; // your MySQL username
        String password = "Kesh@v108"; // your MySQL password

        try {
            Connection conn = DriverManager.getConnection(url, user, password);
            System.out.println("Database Connected Successfully!");
            conn.close();
        } catch (SQLException e) {
            System.out.println("Database Connection Failed!");
            e.printStackTrace();
        }
    }
}
