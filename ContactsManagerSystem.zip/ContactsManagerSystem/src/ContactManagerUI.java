import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

public class ContactManagerUI extends JFrame {
    private JTable table;
    private DefaultTableModel model;
    private ContactDAO dao = new ContactDAO();
    private int selectedId = -1;

    public ContactManagerUI() {
        setTitle("Contact Management System");
        setSize(800, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        String[] cols = {"ID", "Name", "Phone", "Email", "Address"};
        model = new DefaultTableModel(cols, 0);
        table = new JTable(model);
        add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel form = new JPanel(new GridLayout(6, 2));
        JTextField nameField = new JTextField();
        JTextField phoneField = new JTextField();
        JTextField emailField = new JTextField();
        JTextField addressField = new JTextField();
        JButton addButton = new JButton("Add");
        JButton updateButton = new JButton("Update");
        JButton deleteButton = new JButton("Delete");

        form.add(new JLabel("Name:"));    form.add(nameField);
        form.add(new JLabel("Phone:"));   form.add(phoneField);
        form.add(new JLabel("Email:"));   form.add(emailField);
        form.add(new JLabel("Address:")); form.add(addressField);
        form.add(addButton);              form.add(updateButton);
        form.add(deleteButton);           form.add(new JLabel());

        add(form, BorderLayout.SOUTH);

        loadContacts();

        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int row = table.getSelectedRow();
                selectedId = (int) model.getValueAt(row, 0);
                nameField.setText((String) model.getValueAt(row, 1));
                phoneField.setText((String) model.getValueAt(row, 2));
                emailField.setText((String) model.getValueAt(row, 3));
                addressField.setText((String) model.getValueAt(row, 4));
            }
        });

        addButton.addActionListener(e -> {
            Contact c = new Contact(
                nameField.getText(),
                phoneField.getText(),
                emailField.getText(),
                addressField.getText()
            );
            dao.addContact(c);
            loadContacts();
            clearFields();
        });

        updateButton.addActionListener(e -> {
            if (selectedId != -1) {
                Contact c = new Contact(
                    selectedId,
                    nameField.getText(),
                    phoneField.getText(),
                    emailField.getText(),
                    addressField.getText()
                );
                dao.updateContact(c);
                loadContacts();
                clearFields();
            }
        });

        deleteButton.addActionListener(e -> {
            if (selectedId != -1) {
                int confirm = JOptionPane.showConfirmDialog(null, "Delete this contact?");
                if (confirm == JOptionPane.YES_OPTION) {
                    dao.deleteContact(selectedId);
                    loadContacts();
                    clearFields();
                }
            }
        });
    }

    void loadContacts() {
        model.setRowCount(0);
        for (Contact c : dao.getAllContacts()) {
            model.addRow(new Object[]{c.getId(), c.getName(), c.getPhone(), c.getEmail(), c.getAddress()});
        }
    }

    void clearFields() {
        selectedId = -1;
        for (Component comp : ((JPanel) getContentPane().getComponent(1)).getComponents()) {
            if (comp instanceof JTextField) ((JTextField) comp).setText("");
        }
    }
}
